% wsgui: Main program for Workspace Tool

%   Copyright 1991-2004 MUSYN Inc. and The MathWorks, Inc.
error(message('Robust:gui:wsgui'))
