%% MAIN SCRIPT
% This main script runs the individual scripts for every part of the
% assignemnt by calling the in the right order

% Influence of the Accelerometer
Accelerometer;

disp('Press a KEY to start the Linearization and Reduction of the state-space model.');

% Linearization and Computation of Reduced Matrices
Linearization;